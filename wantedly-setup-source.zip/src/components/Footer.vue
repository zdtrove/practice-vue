<template>
    <v-footer color="#970747" dark fixed>
        <v-spacer></v-spacer>
        <div>WANTEDLY &copy; {{ new Date().getFullYear() }}</div>
        <v-spacer></v-spacer>
    </v-footer>
</template>

<script>
    export default {
        name: 'Footer',
    };
</script>

<style>

</style>