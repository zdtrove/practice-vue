<template>
    <div>
        <Header />
        <v-content>
            <slot />
        </v-content>
        <Footer />
    </div>
</template>

<script>
    import Header from '../../components/Header';
    import Footer from '../../components/Footer';
    export default {
        name: 'DashboardLayout',
        components: {
            Header,
            Footer
        }
    };
</script>

<style>

</style>